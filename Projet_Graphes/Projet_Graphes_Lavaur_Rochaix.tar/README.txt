La limite de l'archive sur moodle étant de 20 Mo nous n'avons pas pu mettre les images dans l'archive.

Il faut donc lancer tous les codes du notebook ("Run All") pour obtenir les images générées.